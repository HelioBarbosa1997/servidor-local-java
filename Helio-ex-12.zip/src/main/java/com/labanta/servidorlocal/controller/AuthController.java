package com.labanta.servidorlocal.controller;

import com.labanta.servidorlocal.dto.LoginRequestDTO;
import com.labanta.servidorlocal.exception.LoginInvalidoException;
import com.labanta.servidorlocal.security.JwtService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthController {
    private final JwtService jwtService;

    public AuthController(JwtService jwtService) {
        this.jwtService = jwtService;
    }

    @PostMapping("/api/auth/login")
    public String login(@RequestBody LoginRequestDTO pedido) {

        if (pedido.getUsername().equals("admin")
        && pedido.getPassword().equals("12345")) {

            return jwtService.gerarToken(pedido.getUsername());
        }
        throw new LoginInvalidoException("Dados Inavalidos");
    }
}
